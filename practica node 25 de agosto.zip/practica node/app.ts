import dotenv from 'dotenv'


//configurar dot.env
dotenv.config()